<?php
/**
 * @package Fat32_plugins
 * @version 1.0
 */
/*
Plugin Name: FAT32 Frontend File Uploader
Plugin URI: http://wordpress.org/plugins/fat32
Description: Give your users an option to upload files from the frontend
Author: Kanhai Lal Murmu
Version: 1.0
Author URI: http://kanhailalmurmu.co.in/
*/

define( 'CUSTOM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
require_once(CUSTOM_PLUGIN_DIR.'inc/plugin-setup.php');
require_once(CUSTOM_PLUGIN_DIR.'inc/api.php');
require_once(CUSTOM_PLUGIN_DIR.'inc/features.php');

function fdebug($var){
    // enable error reporting for php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    echo '<pre>'; print_r($var); echo '</pre>';
}
// fdebug('Plugins direc path '.CUSTOM_PLUGIN_DIR);
require CUSTOM_PLUGIN_DIR.'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://fat32.tech/assets/json/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'f32_settings'
);

add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_f32_action_links' );
function add_f32_action_links( $actions ) {
//   $newAction = ['<a href="'. esc_url( get_admin_url(null, 'options-general.php?page=fat32_settings') ) .'">Settings</a>'];
  $newAction = ['<a href="' . admin_url( 'admin.php?page=fat32_settings' ) . '">Settings</a>'];
  // $newAction = ['<a href="http://wp-buddy.com" target="_blank">More plugins by WP-Buddy</a>'];
  return array_merge($newAction,$actions);
}
?>