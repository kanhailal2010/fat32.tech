<?php

function enqueue_f32_scripts() {
  // Adding JS
  wp_enqueue_script('fat32_js_front',plugin_dir_url( __FILE__ ).'../js/fat32-frontend.js',array('jquery'));
  wp_localize_script( 'fat32_js_front', 'fat32', array(
      'ajax_url' => admin_url( 'admin-ajax.php' ),
      'nounce'  => wp_create_nonce("Secret Text by by Fat32 Inc"),
    ));

  // Adding CSS
  wp_enqueue_style('fontawesome4.2', '//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css');
  wp_enqueue_style('fat32-css-front',plugin_dir_url( __FILE__ ).'../css/fat32-frontend.css');


}
add_action( 'wp_enqueue_scripts', 'enqueue_f32_scripts' );

// enque on plugin-settings page load (check method f32_admin_page)
function enqueue_f32_scripts_admin_toplevel_page_fat32_settings() {
  // Adding JS
  wp_enqueue_script('fat32_js_admin',plugin_dir_url( __FILE__ ).'../js/fat32-admin.js',array('jquery'));
  wp_localize_script( 'fat32_js_admin', 'fat32', array(
      'ajax_url' => admin_url( 'admin-ajax.php' ),
      'nounce'  => wp_create_nonce("Secret Text by by Fat32 Inc"),
    ));

  // Adding CSS
  wp_enqueue_style('fontawesome4.2', '//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css');
  wp_enqueue_style('fat32-css-admin',plugin_dir_url( __FILE__ ).'../css/fat32-admin.css');
}
// add_action('admin_enqueue_scripts', 'enqueue_f32_scripts_admin');

/*
 * Add the admin page
 */
add_action('admin_menu', 'f32_admin_page');
function f32_admin_page(){
    // enqueue_f32_scripts_admin_toplevel_page_fat32_settings();
    $hook = add_menu_page('Fat32 File Upload Settings', 'Fat32 Settings', 'administrator', 'fat32_settings', 'f32_admin_page_callback');
    add_action( "admin_print_scripts-$hook", "enqueue_f32_scripts_admin_$hook" );
}

// add_action( "admin_print_styles-$hook", "my_enqueue_style" );
// add_action( "admin_print_scripts-$hook", "my_enqueue_script" );


/*
 * Register the settings
 */
add_action('admin_init', 'f32_register_settings');
function f32_register_settings(){
    //this will save the option in the wp_options table as 'f32_settings'
    //the third parameter is a function that will validate your input values
    add_option( 'f32_settings', [
      "no_of_fields"  => 1,
      "last_index"  => 1,
      "field_indexes" => [],
      "upload_field_title_1"  => "Field Title",
      "upload_button_title_1" => "Upload",
      "f32_upload_1" => "field_name",
      "f32_file_1"  => "renamed_file",
      ]);
    register_setting('f32_settings', 'f32_settings', 'f32_settings_validate');
}

function f32_settings_validate($args){
    //$args will contain the values posted in your settings form, you can validate them as no spaces allowed, no special chars allowed or validate emails etc.
    if(!isset($args['no_of_fields']) || empty($args['no_of_fields'])){
        $args['no_of_fields'] = '';
      add_settings_error('f32_settings', 'not_a_valid_number', 'Please enter a valid number!', $type = 'error');   
    }
    //make sure you return the args
    return $args;
}

function getAllowedFileTypeMaps($type = null){
  $filetype_map = [
		'image' 		=> ['jpg','jpeg','png','bmp','webp'],
		'document' 	=> ['pdf', 'doc', 'docx']
	];
  return ($type) ? $filetype_map[$type] : $filetype_map;
}

function getFileIndexFromName($name){
  $exp = explode("_",$name);
  $count = count($exp);
  return $exp[($count-1)];
}

function radio_select($selected_type, $input_type) {
  if($selected_type == $input_type) { return 'checked'; }
}

//The markup for your plugin settings page
function f32_admin_page_callback(){ ?>
  <div class="fat32-admin-wrap">
    <h1>FAT32 Frontend File Upload Settings</h1>

    <div class="shortcode_info">
    Paste this <strong>Shortcode</strong> where you want to add Multiple file upload feature <code>[fat32_file_upload]</code>
    </div>

    <h3>Configuration</h3>
    <form action="options.php" method="post" id="f32_settings_form"><?php
        settings_fields( 'f32_settings' );
        do_settings_sections( __FILE__ );

        //get the older values, wont work the first time
        $options        = get_option( 'f32_settings' ); 
        $no_of_fields   = (isset($options['no_of_fields']) && $options['no_of_fields']!=='') ? $options['no_of_fields'] : 1;
        $field_indexes  = (isset($options['field_indexes']) && !empty($options['field_indexes'])) ? explode(",",$options['field_indexes']) : [1];
        $last_field_index = end($field_indexes) ? end($field_indexes) : 0;
        $last_index     = (isset($options['last_index']) && !empty($options['last_index']) && $options['last_index']!=='NaN' && $options['last_index'] >= $options['no_of_fields'] ) ? $options['last_index'] : $last_field_index;
        ?>
        No of Input fields
        <input name="f32_settings[no_of_fields]" type="text" readonly="true" id="no_of_fields" value="<?php echo $no_of_fields;?>">
        <span class="button" id="cloneButton">Add More Upload Fields</span>
        <br/><br/>
        <input name="f32_settings[last_index]" type="hidden" id="last_index" value="<?php echo $last_index;?>">
        <input name="f32_settings[field_indexes]" type="hidden" id="field_indexes" value="<?php echo $field_indexes;?>">
          
        <?php 
        // generate fields based on no_of_fields
        // $fieldset_count = 0;
        $start_count = ($last_index - $no_of_fields);
        // TODO: we don't need this for loop, change to forEach an loop through the saved fileds
        // for($i=($start_count<=0)? 1: $start_count; $i<=$no_of_fields; $i++) {
        foreach ($field_indexes as $key=>$f_index) {
          $upload_file_title = (isset($options['upload_field_title_'.$f_index]) && $options['upload_field_title_'.$f_index]!=='') ? $options['upload_field_title_'.$f_index] : "Field Title";
          $upload_field_name = (isset($options['f32_upload_'.$f_index]) && $options['f32_upload_'.$f_index]!=='') ? $options['f32_upload_'.$f_index] : "field_name";
          $renamed = (isset($options['f32_file_'.$f_index]) && $options['f32_file_'.$f_index]!=='') ? $options['f32_file_'.$f_index] : "newfile";
          $upload_button_title = (isset($options['upload_button_title_'.$f_index]) && $options['upload_button_title_'.$f_index]!=='') ? $options['upload_button_title_'.$f_index] : "Upload";
          $upload_file_type = (isset($options['upload_file_type_'.$f_index]) && $options['upload_file_type_'.$f_index]!=='') ? $options['upload_file_type_'.$f_index] : "";
          ?>
          <div class="field-set" data-field_index="<?php echo $f_index;?>">
            <div class="row">
              <div>
                <span class="row_no"><?php echo $f_index;?></span>) Field Title 
                <input type="text" data-field_type="field_title" onkeyup="changeNames(this)" name="f32_settings[upload_field_title_<?php echo $f_index;?>]" id="upload_field_title_<?php echo $f_index;?>" value="<?php echo $upload_file_title?>" required="true">
              </div>
              <div>
                Upload Button Title 
                <input type="text" name="f32_settings[upload_button_title_<?php echo $f_index;?>]" id="upload_button_title_<?php echo $f_index;?>" value="<?php echo $upload_button_title;?>" required="true">
              </div>
              <div>
                <label>
                  <input type="radio" id="upload_file_type_document_<?php echo $f_index;?>" name="f32_settings[upload_file_type_<?php echo $f_index;?>]" value="document" required <?php echo radio_select($upload_file_type, 'document');?>/>Document Format
                </label>
                <label>
                  <input type="radio" id="upload_file_type_image_<?php echo $f_index;?>" name="f32_settings[upload_file_type_<?php echo $f_index;?>]" value="image" required <?php echo radio_select($upload_file_type, 'image');?>/>Image Format
                </label>
              </div>
              <div>
                <div class="button" onclick="deleteClone(this)">Remove</div>
              </div>
              <div>
                <input type="hidden" data-field_type="field_name" name="f32_settings[f32_upload_<?php echo $f_index;?>]" id="f32_upload_<?php echo $f_index;?>" value="<?php echo $upload_field_name;?>">
              </div>
              <div>
                <input type="hidden" data-field_rename-to="rename_file" name="f32_settings[f32_file_<?php echo $f_index;?>]" id="f32_file_<?php echo $f_index;?>" value="<?php echo $renamed;?>">
              </div>
            </div> <!-- .row -->
            <!-- <button type="button" class="clone-field-set"> Add More </button> -->
            
          </div> <!--  field-set -->
          <?php
          // $fieldset_count=$f_index;
        }
        
        ?>
        
        <!-- <input type="submit" class="button" value="Save" /> -->
        <div class="ajax-button">
          <div class="fa fa-check-square done"></div>
          <div class="fa fa-close failed"></div>
          <input id="f32_submit" class="f32_submit" type="submit" value="Save" />
        </div>
    </form>

    <br/><br/>
    
    <br/><br/>

</div> <!-- .fat32-admin-wrap -->

<?php }

/**
 * Show custom user profile fields
 * 
 * @param  object $profileuser A WP_User object
 * @return void
 */

 function custom_user_profile_fields( $profileuser ) {
  $options = get_option( 'f32_settings' );
  $field_indexes 	= (isset($options['field_indexes']) && $options['field_indexes']!=='') ? explode(",",$options['field_indexes']) : [];
  $current_user = wp_get_current_user();
  $user_id = isset($_REQUEST['user_id']) ? $_REQUEST['user_id']: $current_user->ID ;

  // $_REQUEST['user_id'];
  // print_r($field_indexes);
  ?>
    <table class="form-table">
      <?php 
      foreach ($field_indexes as $key=>$f_index) :
		    if(isset($options['f32_file_'.$f_index])) :
          $upload_file_type = (isset($options['upload_file_type_'.$f_index]) && $options['upload_file_type_'.$f_index]!=='') ? $options['upload_file_type_'.$f_index] : "";
          // print_r($upload_file_type);
          $file = get_user_meta( $user_id , $options['f32_file_'.$f_index] );
          // $ext = strtolower(end((explode(".", (!empty($file[0]) ? $file[0] : '')))));
          $display_img = 'display:none;';
          $display_file = 'display:none;';
          $file_url = '#';
          $img_url = '';
          if($upload_file_type == 'image' && !empty($file[0])) {
            $display_img = '';
            $img_url = $file[0];
          }
          else if($upload_file_type == 'document' && !empty($file[0])) {
            $display_file = '';
            $file_url = $file[0];
          }
          $filename = basename($file_url);
      ?>
      <tr>
        <th>
          <label for="user_location"><?php _e( $options['upload_field_title_'.$f_index] ); ?></label>
        </th>
        <td>
          <!-- File Preview -->
          <!-- Image -->
          <img src="<?php echo $img_url;?>" class="<?php echo $options['f32_upload_'.$f_index].'-preview'; ?>" id="<?php echo $options['f32_upload_'.$f_index].'-imgprev'; ?>" width="300" style="<?php echo $display_img;?>" >
          <!-- Non-image -->
          <?php echo $filename != '#' ? $filename : '' ;?> 
          <a href="<?php echo $file_url;?>" target="_blank" class="<?php echo $options['f32_upload_'.$f_index].'-preview'; ?>" id="<?php echo $options['f32_upload_'.$f_index].'-fileprev'; ?>" style="<?php echo $display_file;?>"> View File</a>
        </td>
      </tr>
      <?php 

        endif;
      endforeach;
      ?>
    </table>
  <?php
  }
  add_action( 'show_user_profile', 'custom_user_profile_fields' );
  add_action( 'edit_user_profile', 'custom_user_profile_fields' );