<?php

add_shortcode( 'fat32_file_upload', 'fat32_file_upload_func' );
function fat32_file_upload_func( $atts ) {

	$options = get_option( 'f32_settings' ); 

  $no_of_fields 		= (isset($options['no_of_fields']) && $options['no_of_fields']!=='') ? $options['no_of_fields'] : 1;
  $field_indexes 		= (isset($options['field_indexes']) && $options['field_indexes']!=='') ? explode(",",$options['field_indexes']) : [];
	if(!isset($options['no_of_fields'])) { return '<h4>[ Please configure the plugin "Fat32 Frontent File Uploader" to use this shortcode. ]</h4>';}
	// echo '<pre>'.print_r($options,true).'</pre>';
	$filetype_map = getAllowedFileTypeMaps();
	$html = '';
	$html .= '<div class="file_upload_container">';
	$current_user = wp_get_current_user();
	if(!$current_user->ID) { return '<h5>[ Please login to update profile. ]</h5>';}

	foreach ($field_indexes as $key=>$f_index) {
		if(isset($options['f32_file_'.$f_index])) :
		$upload_file_type = (isset($options['upload_file_type_'.$f_index]) && $options['upload_file_type_'.$f_index]!=='') ? $options['upload_file_type_'.$f_index] : "";
		// print_r($upload_file_type);
		$file = get_user_meta( $current_user->ID , $options['f32_file_'.$f_index] );
		// $ext = strtolower(end((explode(".", (!empty($file[0]) ? $file[0] : '')))));
		$display_img = 'display:none;';
		$display_file = 'display:none;';
		$file_url = '#';
		$img_url = '';
		if($upload_file_type == 'image' && !empty($file[0])) {
			$display_img = '';
			$img_url = $file[0];
		}
		else if($upload_file_type == 'document' && !empty($file[0])) {
			$display_file = '';
			$file_url = $file[0];
		}
		$html .= '<div class="f32_frontend_upload_block">';
		$html .= '<h4>'.$options['upload_field_title_'.$f_index].'</h4>';
		$html .= '<input type="file" id="'.$options['f32_upload_'.$f_index].'" name="'.$options['f32_upload_'.$f_index].'" data-fieldtype="'.$upload_file_type.'" class="f32_file_input" >';
		$html .= '<span class="f32_upload_file_types">'.implode(',', getAllowedFileTypeMaps($upload_file_type)).'</span>';
		$html .= '<input type="button" class="but_upload" id="'.$options['f32_upload_'.$f_index].'-submit" name="'.$options['f32_upload_'.$f_index].'-submit"  value="'.$options['upload_button_title_'.$f_index].'">';
		$html .= '<span class="f32_loader" id="f32_loader"></span>';
		$html .= '<div class="validation_msg valid-'.$options['f32_upload_'.$f_index].'"></div>';
		$html .= '</div>';
		$html .= '
				<!-- File Preview -->
				<div class="f32_preview" >
					<!-- Image -->
					<img src="'.$img_url.'" class="'.$options['f32_upload_'.$f_index].'-preview" id="'.$options['f32_upload_'.$f_index].'-imgprev" width="300" style="'.$display_img.'" >
					<!-- Non-image -->
					<a href="'.$file_url.'" target="_blank" class="'.$options['f32_upload_'.$f_index].'-preview" id="'.$options['f32_upload_'.$f_index].'-fileprev" style="'.$display_file.'">View File</a>
				</div>
				';
		endif;
	}
	$html .='</div> <!--  file_upload_container -->';
	$html .= '<script type="text/javascript">';
	$html .= 'var fileUploads = []; ';
	foreach ($field_indexes as $key=>$f_index) {
		if(isset($options['f32_upload_'.$f_index])) :
			$html .= 'fileUploads.push("'.$options['f32_upload_'.$f_index].'");';
		endif;
	}
	// $html .='console.log("File uploads : ",fileUploads);';
	$html .='var filetype_map = {};';
	foreach ($filetype_map as $key => $extensions) {
		$html .= 'filetype_map["'.$key.'"] = [];';
		foreach($extensions as $ext) {
			$html .= 'filetype_map["'.$key.'"].push("'.$ext.'");';
		}
	}
	$html .='console.log("File extension map : ",filetype_map);';
	$html .='</script>';
	// $html .="<pre>";
	// $html .= print_r($options, true);
	// // $html .= print_r($field_indexes, true);
	// $html .="</pre>";
	return $html;
}
