<?php
add_action("wp_ajax_f32_frontend_upload", "f32_ff_uploader");
add_action("wp_ajax_nopriv_f32_frontend_upload", "f32_ff_uploader");

function f32_ff_uploader() {
    $debug = 0;
    $response = [];
    $response['status'] = 0;
    
    $debugres = [];
    $debugres['post_data'] = $_POST;
    $debugres['file_data'] = $_FILES;
    $debugres['status'] = 0;
    $debugres['log'][] = 'New Log start';
    
    $current_user = wp_get_current_user();
    $path = wp_get_upload_dir();
    $folder = '/user_uploads/'.$current_user->user_login;
    $directory = $path['basedir'].$folder;
    $debugres['current_user'] = $current_user->user_login;
    $debugres['wp_upload_dir'] = $path;
    $debugres['log'][] = "uploaded file will be saved in: ".$directory;

    if (!file_exists($directory)) {
        mkdir($directory, 0777, true);
        $debugres['log'][] = "directory created as ".$directory;
    }
    
    if (!function_exists('wp_handle_upload')) {
           require_once(ABSPATH . 'wp-admin/includes/file.php');
       }

	$options = get_option( 'f32_settings' ); 
	$no_of_fields = (isset($options['no_of_fields']) && $options['no_of_fields']!=='') ? $options['no_of_fields'] : 1;
	$field_indexes 	= (isset($options['field_indexes']) && $options['field_indexes']!=='') ? explode(",",$options['field_indexes']) : [];
	/* Allowed file extensions */
	$allowed_extensions = [];//array("jpg","jpeg","png","pdf");
	
	$renamed = [];
	
	foreach ($field_indexes as $key=>$f_index) :
		$renamed[$options['f32_upload_'.$f_index]] = $options['f32_file_'.$f_index];
	endforeach;

	$debugres['renamed_map'] = $renamed;
	foreach ($_FILES as $key => $f):
		$uploadedfile = $_FILES[$key];
		$extension = end((explode(".", $uploadedfile['name'])));
		$extension = strtolower($extension);

		$filename = $renamed[$key].'.'.$extension;//$uploadedfile['name'];//$_FILES['userfile']['name'];
		$location = $directory.'/'.$filename;
		$file_url = $path['baseurl'].$folder.'/'.$filename;

		// get upload filetype from field settings
		// $upload_file_type = $options
		$f_index = getFileIndexFromName($renamed[$key]);
		$debugres['filename_index'][$renamed[$key]] = $f_index;
		$upload_file_type = (isset($options['upload_file_type_'.$f_index]) && $options['upload_file_type_'.$f_index]!=='') ? $options['upload_file_type_'.$f_index] : "";
		$allowed_extensions = getAllowedFileTypeMaps($upload_file_type);
		$debugres['allowed_extension'][$renamed[$key]] = $allowed_extensions;
		
		$debugres['log'][] = "Field name : ".$options['f32_upload_'.$f_index].
							" :File Name: ".$uploadedfile['name']." Extension: ".$extension.
							" Updated Name: ".$filename;
		if(in_array(strtolower($extension), $allowed_extensions)) {
			$debugres['log'][] = "file is in allowed type ";
			/* Upload file */
			if(move_uploaded_file($uploadedfile['tmp_name'],$location)){
				$response['uploaded_file'][$key]['status'] = 1;
				$response['uploaded_file'][$key]['path'] = $file_url;
				$response['uploaded_file'][$key]['extension'] = $extension;
				$response['uploaded_file'][$key]['file_type'] = $upload_file_type;
				$response['uploaded_file'][$key]['response_msg'] = 'Uploaded Sucessfully';
				
				$debugres['uploaded_file'][$key]['status'] = 1;
				$debugres['uploaded_file'][$key]['log'][] = "moved file to folder ".$location;
				$debugres['uploaded_file'][$key]['path'] = $file_url;
				$debugres['uploaded_file'][$key]['extension'] = $extension;
				delete_user_meta( $current_user->ID, $renamed[$key]);
				add_user_meta( $current_user->ID, $renamed[$key], $file_url);

				$response['status'] = 1;
				$debugres['status'] = 1;
			}		
			else {
				$response['uploaded_file'][$key]['status'] = 0;
				$response['uploaded_file'][$key]['response_msg'] = "Upload Failed. Please try again.";
				$debugres['log'][] = "File could not be moved to directory."; 
			}
		}
		else {
			$response['uploaded_file'][$key]['status'] = 0;
			$response['uploaded_file'][$key]['response_msg'] = $extension." file not in allowed for this field.";
			$debugres['log'][] = "File not in allowed extension. Found Extension ".$extension; 
		}
	endforeach;
  echo $debug == 1 ? json_encode($debugres) : json_encode($response);

  exit();
}

// Callback function to save settings
function save_f32_plugin_settings() {
	if (isset($_POST['data'])) {
			parse_str($_POST['data'], $f32Settings); // Parse form data
			
			// update_option('f32_settings', sanitize_text_field($f32Settings['f32_settings']));
			update_option('f32_settings', $f32Settings['f32_settings']);
			exit(serialize($f32Settings['f32_settings']));
			
			// Sanitize and save settings to wp_options
			
			// Add more options as needed
			
			echo 'success';
	} else {
			echo 'error';
	}
	wp_die(); // Always include this to terminate the script properly
}

// Hook the callback function into WordPress AJAX
add_action('wp_ajax_save_f32_plugin_settings', 'save_f32_plugin_settings');
add_action('wp_ajax_nopriv_save_f32_plugin_settings', 'save_f32_plugin_settings'); // For non-logged-in users