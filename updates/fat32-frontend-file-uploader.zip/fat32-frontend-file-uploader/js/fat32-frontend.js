// frontend upload
function display_error(type, msg) {
  let final;
  switch (type) {
    case 'success':
      final = '<div class="success-msg"><i class="fa fa-check"></i> '+msg+'</div>';
      break;
    case 'error':
      final = '<div class="error-msg"><i class="fa fa-times-circle"></i> '+msg+'</div>';
      break;
    case 'info':
      final = '<div class="info-msg"><i class="fa fa-info-circle"></i> '+msg+'</div>';
      break;
  
    default:
      break;
  }
  return final;
}

jQuery(document).ready(function ($) {
  let f32_loader = $('#f32_loader');
  function append_error(element, type, msg) {
    $(element).html(display_error(type, msg)).show().delay(4000).hide(500);
  }

  $('.f32_file_input').on('change', (ele)=>{
    var fileName      = $(ele.target)[0].files[0].name;
    var fileExtension = fileName.split('.').pop().toLowerCase();
    let fieldId       = ele.target.attributes.id.value;
    let field_type    = ele.target.attributes[3].value;
    let allowedExtensions = filetype_map[field_type];
    // console.log(fieldId, field_type, allowedExtensions);

    if (allowedExtensions.indexOf(fileExtension) === -1) {
      append_error($('.valid-'+fieldId), 'error', 'Invalid file type. Allowed only '+allowedExtensions.join(', '));
      return;
    }
  });


  $(".but_upload").click(function () {
    var form_data = new FormData();
    f32_loader.show();

    for (let i = 0; i < fileUploads.length; i++) {
      let files       = $("#" + fileUploads[i])[0].files;
      form_data.append(fileUploads[i], files[0]);
    }

    form_data.append("action", "f32_frontend_upload");
    form_data.append("nounce", fat32.nounce);
    $.ajax({
      url: fat32.ajax_url,
      type: "post",
      data: form_data,
      dataType: "json",
      contentType: false,
      processData: false,
      success: function (response) {
        f32_loader.hide();
          //  console.log("upload response ",response);
        if (response.status == 1) {
          for (let fieldId in response.uploaded_file) {
            $(`.${fieldId}-preview`).hide();
            var extension = response.uploaded_file[fieldId].extension;
            var path      = response.uploaded_file[fieldId].path;
            var status    = response.uploaded_file[fieldId].status;
            var res_msg   = response.uploaded_file[fieldId].response_msg;
            let file_type = response.uploaded_file[fieldId].file_type;

            append_error($(`.valid-${fieldId}`),(status == 1 ? 'success' : 'error'), res_msg);

            if (file_type == "document") {
              $(`#${fieldId}-fileprev`).attr("href", path);
              $(`#${fieldId}-fileprev`).show();
            } else {
              $(`#${fieldId}-imgprev`).attr("src", path);
              $(`#${fieldId}-imgprev`).show();
            }
          }
        }
        else {
          // console.log("checking for status 0");
          append_error($('.validation_msg'), 'info', 'Nothing Uploaded');
          for (let fieldId in response.uploaded_file) {
            var status    = response.uploaded_file[fieldId].status;
            var res_msg   = response.uploaded_file[fieldId].response_msg;
            append_error($(`.valid-${fieldId}`),(status == 1 ? 'success' : 'error'), res_msg);
          }
        }
      },
      error: function (response) {
        //    console.log(response);
        append_error($('.validation_msg'), 'error', 'Something is wrong with file Uploaded');
      }
    });
  });
});