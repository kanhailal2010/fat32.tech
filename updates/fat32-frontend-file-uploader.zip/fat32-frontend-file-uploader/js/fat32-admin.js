// backend admin 
// change the values of field_name and renamed file name
function changeNames(ele){
  let grandparent = ele.parentElement.parentElement.parentElement;
  let fieldIndex = grandparent.getAttribute('data-field_index');
  
  
  let fieldNameId = `f32_upload_${fieldIndex}`;
  let renameFileId = `f32_file_${fieldIndex}`;
  let fieldNameEle = document.getElementById(fieldNameId);
  let renameFileEle = document.getElementById(renameFileId);
  let newValue = ele.value.toLowerCase().replace(/ /g, "_");
  renameFileEle.value = newValue+'_'+fieldIndex;
  fieldNameEle.value = newValue+'_'+fieldIndex;
}

function getFieldIndexes() {
  var fieldIndexes = [];
  document.querySelectorAll('*[data-field_index]').forEach(ele => {
    
    fieldIndexes.push(ele.getAttribute('data-field_index'));
  });

  document.getElementById('field_indexes').value = fieldIndexes.join(',');
  return fieldIndexes;
}

function getLastIndex() {
  let indexArray = getFieldIndexes();
  let lastIndex = indexArray[(indexArray.length-1)];
  return lastIndex;
}

function updateNoOfFields(on_delete) {
  let count = document.querySelectorAll('.field-set').length;
  if(on_delete) { count--;}
  
  document.getElementById('no_of_fields').value = count <= 0 ? 1 : count;
  return count;
}

function deleteClone(obj) {
  if(updateNoOfFields(true) > 0){
    obj.closest('.field-set').remove();
  }
  getFieldIndexes();
  updateSerialNo();
  return false;
}

function updateSerialNo(){
  let c = 1;
  let rowElement = document.querySelectorAll('.field-set');
  
  rowElement.forEach((ele) => {
    ele.querySelector('.row_no').innerHTML = c;
    
    c++;
  });
}

jQuery(document).ready(function($){
  updateSerialNo();
  // set up field_indexes field value
  let cloneIndex = getLastIndex();
  $('#last_index').val(cloneIndex);

  $('#cloneButton').click(function() {
    var $cloneContainer = $('.field-set:last').clone();
    var $inputs = $cloneContainer.find('input');

    cloneIndex++;
    $cloneContainer.attr('data-field_index', cloneIndex);
    
    $('#last_index').val(cloneIndex);
    
    // Update id, name, and value attributes for cloned elements
    $inputs.each(function() {
      var oldId = $(this).attr('id');
      var oldName = $(this).attr('name');
      var oldValue = $(this).val();
      let regex = /\_[0-9]+/g;

      var newId = oldId.replace(regex, "_"+cloneIndex);
      var newName = oldName.replace(regex, "_"+cloneIndex);
      // var newValue = 'field_value_' + cloneIndex;
      
      $(this).attr('id', newId);
      $(this).attr('name', newName);
      // $(this).val(newValue);
      
      // Check for input with data-field-type="field_name"
      if ($(this).data('field-type') === 'field_name') {
        $(this).on('input', function() {
          if ($(this).val().indexOf(' ') !== -1) {
            alert('Spaces are not allowed in field names.');
            $(this).val($(this).val().replace(/\s/g, '')); // Remove spaces
          }
        });
      }
    });

    // Append the cloned element to the container
    $('.field-set:last').after($cloneContainer);
    getFieldIndexes();
    updateNoOfFields();
    updateSerialNo();
    // cloneIndex++;
  });

  function resetSubmitAnimation() {
    setTimeout(function() {
      $(".f32_submit").removeClass("f32_submit_loading");
      $(".f32_submit").removeClass("hide-f32_submit_loading");
      $(".done").removeClass("f32_finish");
      $(".failed").removeClass("f32_finish");
    }, 2000);
  }

  $('#f32_settings_form').on('submit', function(e) {
    e.preventDefault();
    $(".f32_submit").addClass("f32_submit_loading");
    // Collect form data
    var formData = $(this).serialize();
    

    // AJAX request
    $.ajax({
        type: 'POST',
        url: fat32.ajax_url, // WordPress AJAX URL
        data: {
            action: 'save_f32_plugin_settings', // Action to trigger the PHP function
            data: formData
        },
        success: (response) => {
          $(".f32_submit").addClass("hide-f32_submit_loading");
          $(".done").addClass("f32_finish");
          resetSubmitAnimation();
        },
        error: () => {
          $(".f32_submit").addClass("hide-f32_submit_loading");
          $(".failed").addClass("f32_finish");
          resetSubmitAnimation();
        }
    });
  });

  // var inputElements = $('[data-field_type="field_title"]');
  // inputElements.each(()=>{
  //   $(this).
  // });
  // $('[data-field_type="field_title"]').on('keydown',()=>{
  
  // });
  function checkDuplicate() {}
});